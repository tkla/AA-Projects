require "byebug"

def partition(arr, n)
    res = Array.new(2){[]}

    arr.each do |i|
        i < n ? res[0] << i : res[1] << i
    end

    res
end

def merge(h1, h2)
    hash = Hash.new()
    h1.each { |key, v|    hash[key] = v }
    h2.each { |key, v|    hash[key] = v }

    hash
end

def censor(str, arr)
    vowel = "aeiou"
    cen = '*'
    res = str.split
    
    res.each do |w| 
        if arr.include?(w.downcase)
            w.each_char.with_index{ |c, i| w[i] = cen if vowel.include?(c.downcase) }
        end
    end

    res.join(" ")
end

def power_of_two?(n)
    return true if n == 1

    sum = n
    (2..n).reverse_each do |i| 
        return true if sum == 1
        if sum % 2 != 0
            return false
        else
            sum/=2
        end
    end
    true
end