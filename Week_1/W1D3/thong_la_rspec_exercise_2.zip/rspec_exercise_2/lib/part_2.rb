require "byebug"

def palindrome?(str)
    str
    s = ""
    
    i = str.length - 1 

    while i >= 0 
        s += str[i]
        i -= 1
    end

    s == str
end

def substrings(str) 
    res = [] 

    str.each_char.with_index do |c, i|
        tmp = ""
        str[i..-1].each_char do |c|
            tmp += c 
            res << tmp 
        end
    end
    res
end

def palindrome_substrings(str)
    sub = substrings(str)
    res = []

    sub.each do |i| 
        res << i if palindrome?(i) && i.length > 1
    end

    res
end