require "byebug"

def my_reject(arr, &b)
    #arr.select{ |i| !b.call(i)}
    res = []

    arr.each { |i| res << i if !b.call(i)}
    res
end

def my_one?(arr, &b)
    count = 0

    arr.each do |i|
        count += 1 if b.call(i)
        return false if count > 1
    end

    count == 1 ? true : false
end

def hash_select(hash, &b)
    h = {}

    hash.each do |k, v|
        h[k] = v if b.call(k,v)
    end
    h
end

def xor_select(arr, p1, p2)
    arr.select { |i| p1.call(i) ^ p2.call(i)}
end

def proc_count(v, arr)
    arr.inject(0) { |acc, i| i.call(v)? acc += 1: acc}
end