require "byebug"

def is_prime?(n)
    return false if n < 2

    (2..n/2).each{ |i| return false if n % i == 0}
    true
end

def nth_prime(n) 
    first = 2
    primes= []

    while primes.length < n 
        primes << first if is_prime?(first)
        first += 1
    end
    primes[-1]
end

def prime_range(min, max) 
    prime = []

    (min..max).each{ |i| prime << i if is_prime?(i)}
    prime
end