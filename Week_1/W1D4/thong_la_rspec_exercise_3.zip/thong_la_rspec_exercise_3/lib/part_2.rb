require "byebug"

def element_count(arr)
    hash = Hash.new(0)

    arr.each { |i| hash[i] += 1}
    hash
end

def char_replace!(str, hash)
    str.each_char.with_index do |c, i|
        str[i] = hash[c] if hash.has_key?(c) 
    end
end

def product_inject(arr) 
    arr.inject { |acc, i| acc *= i}
end