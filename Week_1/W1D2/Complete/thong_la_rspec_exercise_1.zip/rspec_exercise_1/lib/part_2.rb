def hipsterfy (str)
    vowel = "aeiou"
    rev = str.reverse

    rev.each_char.with_index do |c, i| 
        if vowel.include?(c.downcase)
            rev[i] = ""
            return rev.reverse
        end
    end

    str
end

def vowel_counts (str)
    hash = Hash.new(0)
    vowel = "aeiou"

    str.each_char do |c|
        hash[c.downcase] += 1 if vowel.include?(c.downcase)
    end

    hash
end

def caesar_cipher(str, n)
    alphabet = "abcdefghijklmnopqrstuvwxyz"

    shift = n.abs % alphabet.length

    shift *= -1 if n < 0

    str.each_char.with_index do |c, i|
        if alphabet.include?(c.downcase)
            newIdx = alphabet.index(c.downcase) + shift
            #Positive shift
            newIdx = newIdx - alphabet.length if newIdx >= alphabet.length 
            #negative shift
            newIdx = newIdx + alphabet.length if newIdx < 0
            str[i] = alphabet[newIdx]
        end
    end
    str
end

