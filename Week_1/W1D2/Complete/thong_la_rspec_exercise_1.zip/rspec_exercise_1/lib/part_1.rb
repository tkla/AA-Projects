def average(num1, num2)
    (num1 + num2) / 2.0

end

def average_array(arr)
    arr.sum/arr.length.to_f
end

def repeat(str, num)
    r = ""

    num.times{|i| r += str}
    r
end

def yell(str)
    r = str.upcase
    r += "!" if str[-1] != "!" 
end

def alternating_case(str)
    flip = 1
    r = str.split

    r.each_with_index do |s, i|
        r[i] = s.upcase if flip == 1
        r[i] = s.downcase if flip == -1

        flip *= -1
    end

    r.join(" ")
end