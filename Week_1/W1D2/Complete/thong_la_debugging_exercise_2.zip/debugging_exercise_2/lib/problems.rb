# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.
require "byebug"

def largest_prime_factor(num)
    n = 0

    (2..num).each do |i|
        n = i if num % i == 0 && prime?(i)  && i > n
    end

    n
end

def prime?(num)
    (2..num/2).each{ |i| return false if num % i == 0}
    true
end

def unique_chars?(str)
    hash = Hash.new(0)

    str.each_char do |c|
        if hash.has_key?(c) 
            return false
        else 
            hash[c] += 1
        end
    end
    true 
end

def dupe_indices(arr)
    repeat = Hash.new{[]}
    result = Hash.new{[]}

    arr.each.with_index do |n, i| 
        if repeat.has_key?(n) 
            result[n] = repeat[n] << i 
        else 
            repeat[n] = repeat[n] << i 
        end
    end
    result
end

def ana_array(arr1, arr2)
    hash1 = Hash.new(0)
    hash2 = Hash.new(0)
    arr1.each{|i| hash1[i] += 1}
    arr2.each{|i| hash2[i] += 1}

    return hash1 == hash2

end
