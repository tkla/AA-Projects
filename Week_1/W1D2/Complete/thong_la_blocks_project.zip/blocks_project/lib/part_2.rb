require "byebug"

def all_words_capitalized?(arr)
    arr.all? do |word|
        return false if word[0] != word[0].upcase
        word[1..-1].each_char{ |c| return false if c != c.downcase}
        true
    end
end

def no_valid_url?(arr)
    valid = ["com", "net", "io", "org"]

    arr.none? do |i|
        url = i.split(".")
        valid.include?(url[1])
    end
end

def any_passing_students?(arr)
    arr.any?{ |i| true if i[:grades].sum / i[:grades].size >= 75}
end