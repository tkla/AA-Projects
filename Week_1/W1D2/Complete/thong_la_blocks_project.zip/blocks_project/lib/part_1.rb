require "byebug"

def select_even_nums(nums)
    nums.select{|i| i % 2 == 0}
end

def reject_puppies(arr)
    arr.reject{ |i| i["age"] < 3}
end

def count_positive_subarrays(arr)
    arr.count{ |i| i.sum > 0}
end

def aba_translate(str)
    res = ""

    str.each_char do |c| 
        res += c
        res += 'b' + c if "aeiou".include?(c.downcase) 
    end

    res
end

def aba_array(arr)
    arr.map{|c| aba_translate(c)}
end