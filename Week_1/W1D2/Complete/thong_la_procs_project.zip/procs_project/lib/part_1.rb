require "byebug"

def my_map(arr, &block)
    res = []
    arr.each{ |i| res << block.call(i)}
    res
end

def my_select(arr, &block)
    res = []
    arr.each{ |i| res << i if block.call(i) }
    res
end

def my_count(arr, &block)
    arr.inject(0) do |acc, i|
        acc += 1 if block.call(i) 
        acc
    end
end

def my_any?(arr, &block)
    arr.each{ |i| return true if block.call(i)}
    false
end

def my_all?(arr, &block)
    arr.each{ |i| return false if !block.call(i)}
    true
end

def my_none?(arr, &block)
    arr.each{ |i| return false if block.call(i)}
    true
end