require "byebug"

def reverser(str, &b)
    b.call(str.reverse)
end

def word_changer(str, &b)
    res = []

    str.split().each do |w|
        res << b.call(w)
    end

    res.join(" ")
end

def greater_proc_value(n, p1, p2)
    n1 = p1.call(n)
    n2 = p2.call(n)

    n1 > n2 ? n1 : n2    
end

def and_selector(arr, p1, p2)
    arr.select{ |i| p1.call(i) && p2.call(i) }
end

def alternating_mapper(arr, p1, p2)
    arr.map.with_index{ |n, i| i % 2 == 0? p1.call(n) : p2.call(n)}
end