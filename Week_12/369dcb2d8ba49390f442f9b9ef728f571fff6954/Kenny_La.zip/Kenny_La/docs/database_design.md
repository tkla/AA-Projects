# Database Schema

## reports
column name   | data type | details
--------------|-----------|-----------------------
id            | integer   | not null, primary key
understanding | text      | not null
improvement   | text      | not null
created_at    | datetime  | not null
updated_at    | datetime  | not null
